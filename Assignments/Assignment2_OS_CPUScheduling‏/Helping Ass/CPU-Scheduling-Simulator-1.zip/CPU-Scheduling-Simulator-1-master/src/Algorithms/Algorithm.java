package Algorithms;
import java.util.ArrayList;
import Processes.Process;

public abstract class Algorithm {	
	public abstract void Simulate();
}
