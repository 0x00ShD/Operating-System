/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment3;

/**
 *
 * @author Mahmoud Ahmed
 */
public class ProcessGUI
{
    public String name;
    public String color;
    public int start;
    public int end;
    
    public ProcessGUI()
    {
        
    }
    public void test()
    {
        System.out.println("Name: "+ name + " - Color: " + color 
                + " start: " +  start + " end: " +
                end);
    }
}
