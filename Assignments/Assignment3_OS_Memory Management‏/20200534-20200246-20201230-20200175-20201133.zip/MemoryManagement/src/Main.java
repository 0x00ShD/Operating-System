import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        int num_of_process;
        int num_of_partition;
        String proc_name;
        int proc_size;
        String parti_name;
        int parti_size;

        try (Scanner in = new Scanner(System.in)) {
            /*** Partition ***/

            System.out.println("Enter number of partition: ");

            num_of_partition = in.nextInt();
            Partition[] parti;
            parti = new Partition[num_of_partition];

            for (int i = 0; i < num_of_partition; i++) {
                System.out.println("Enter Parti name: ");
                String na = in.next();
                System.out.println("\nEnter Parti size: ");
                int si = in.nextInt();
                parti_name = na;
                parti_size = si;
                parti[i] = new Partition(parti_name, parti_size);

            }

            /*** process ******/

            System.out.println("Enter number of processes: ");

            num_of_process = in.nextInt();
            Process[] proc;
            proc = new Process[num_of_process];

            for (int j = 0; j < num_of_process; j++) {
                System.out.println("Enter process name: ");
                String na = in.next();
                System.out.println("\nEnter process size: ");
                int si = in.nextInt();
                proc_name = na;
                proc_size = si;
                proc[j] = new Process(proc_name, proc_size);

            }
            /***** Menu *****/

            boolean temp = true;
            while (temp == true) {
                System.out.println("Select the policy you want to apply:");
                System.out.println("1. Best fit");
                System.out.println("2. Worst fit");
                System.out.println("3. First fit");
                System.out.println("4. Exit");

                int policy = in.nextInt();
                switch (policy) {
                    case 1:
                        test.bestFit(parti, num_of_partition, proc, num_of_process);
                        break;
                    case 2:
                        test.worstFit(parti, num_of_partition, proc, num_of_process);
                        break;
                    case 3:
                        test.firstFit(parti, num_of_partition, proc, num_of_process);
                        break;
                    case 4:
                        temp = false;
                        break;
                    default:
                        System.out.println("INVALID CHOICE!");
                        break;

                }
            }

        }
    }

}