class Partition {
    String parti_name;
    int parti_size;

    public Partition(String parti_name, int parti_size) {
        this.parti_name = parti_name;
        this.parti_size = parti_size;

    }
}