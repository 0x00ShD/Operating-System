class Process {
    String p_name;
    int p_size;
    public Process(String p_name, int p_size) {
        this.p_name = p_name;
        this.p_size = p_size;

    }
}