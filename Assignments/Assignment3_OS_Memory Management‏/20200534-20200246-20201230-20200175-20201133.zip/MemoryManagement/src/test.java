public class test {

    /******** Best fit **********/
    static void bestFit(Partition blockSize[], int m, Process processSize[], int n) {
        int b_s[] = new int[m];
        for (int i = 0; i < m; i++)
            b_s[i] = blockSize[i].parti_size;

        int p_s[] = new int[n];
        for (int i = 0; i < n; i++)
            p_s[i] = processSize[i].p_size;

        int patis_size[] = new int[m];
        for (int i = 0; i < m; i++)
            patis_size[i] = blockSize[i].parti_size;

        int proce_size[] = new int[n];
        for (int i = 0; i < n; i++)
            proce_size[i] = processSize[i].p_size;

        for (int i = 0; i < proce_size.length; i++)
            proce_size[i] = -1;

        for (int i = 0; i < n; i++) {
            int bestIdx = -1;
            for (int j = 0; j < m; j++) {
                if (b_s[j] >= p_s[i]) {
                    if (bestIdx == -1)
                        bestIdx = j;
                    else if (b_s[bestIdx] > b_s[j])
                        bestIdx = j;
                }
            }

            // If we could find a block for current process
            if (bestIdx != -1) {
                // allocate block j to p[i] process
                proce_size[i] = bestIdx;

                // Reduce available memory in this block.
                b_s[bestIdx] -= p_s[i];

//                /**** old ****/
//                int old[] = new int[m+20];
//                for (int o = 0; o < m; o++)
//                    old[o] = b_s[i];
//
//                int new_parti = b_s[bestIdx];
//
//                for (int k = bestIdx + 1; k < b_s.length ; k++) {
//                    if (k == bestIdx + 1) {
//                        b_s[k] = new_parti;
//                    } else {
//                        b_s[k] = old[k-1];
//
//                    }

            }
        }

        System.out.println("Fragmentation:");
        for (int i = 0; i < b_s.length; i++) {
            System.out.println(b_s[i]);
        }

        System.out.println("\nProcess Name\t\tProcess Size\t\t Partition no.");
        for (int i = 0; i < n; i++) {
            System.out.print(" " + processSize[i].p_name + "\t\t\t\t\t\t" + processSize[i].p_size + "\t\t\t\t\t\t");
            int partition = proce_size[i];
            if (proce_size[i] != -1)
                System.out.print("Partition" + partition);
            else
                System.out.print("Not Allocated");
            System.out.println();
        }

//        /******* Partition free space *******/
//
//        System.out.println("Partition free space:");
//        for (int i = 0; i < m; i++) {
//            if (b_s[i] != 0) {
//                System.out.println(blockSize[i].parti_name + " = " + b_s[i]);
//            }
//        }
    }

    /******** Worst fit **********/

    static void worstFit(Partition blockSize[], int m, Process processSize[], int n) {
        int b_s[] = new int[m];
        for (int i = 0; i < m; i++)
            b_s[i] = blockSize[i].parti_size;

        int p_s[] = new int[n];
        for (int i = 0; i < n; i++)
            p_s[i] = processSize[i].p_size;

        int patis_size[] = new int[m];
        for (int i = 0; i < m; i++)
            patis_size[i] = blockSize[i].parti_size;

        int proce_size[] = new int[n];
        for (int i = 0; i < n; i++)
            proce_size[i] = processSize[i].p_size;

        for (int i = 0; i < proce_size.length; i++)
            proce_size[i] = -1;

        for (int i = 0; i < n; i++) {
            int bestIdx = -1;
            for (int j = 0; j < m; j++) {
                if (b_s[j] >= p_s[i]) {
                    if (bestIdx == -1)
                        bestIdx = j;
                    else if (b_s[bestIdx] < b_s[j])
                        bestIdx = j;
                }
            }

            // If we could find a block for current process
            if (bestIdx != -1) {
                // allocate block j to p[i] process
                proce_size[i] = bestIdx;

                // Reduce available memory in this block.
                b_s[bestIdx] -= p_s[i];
            }
        }
        System.out.println("Fragmentation:");
        for (int i = 0; i < b_s.length; i++) {
            System.out.println(b_s[i]);
        }


        System.out.println("\nProcess Name\t\tProcess Size\t\tPartition no.");
        for (int i = 0; i < n; i++) {
            System.out.print(" " + processSize[i].p_name + "\t\t\t\t\t\t" + processSize[i].p_size + "\t\t\t\t");
            int partition = proce_size[i];
            if (proce_size[i] != -1)
                System.out.print("Partition" + partition);
            else
                System.out.print("Not Allocated");
            System.out.println();
        }
//        /******* Partition free space *******/
//        System.out.println("Partition free space:");
//        for (int i = 0; i < m; i++) {
//            if (b_s[i] != 0) {
//                System.out.println(blockSize[i].parti_name + " = " + b_s[i]);
//            }
//        }
    }

    // /********First fit**********/
    static void firstFit(Partition blockSize[], int m, Process processSize[], int n) {
        int b_s[] = new int[m];
        for (int i = 0; i < m; i++)
            b_s[i] = blockSize[i].parti_size;

        int p_s[] = new int[n];
        for (int i = 0; i < n; i++)
            p_s[i] = processSize[i].p_size;

        int patis_size[] = new int[m];
        for (int i = 0; i < m; i++)
            patis_size[i] = blockSize[i].parti_size;

        int proce_size[] = new int[n];
        for (int i = 0; i < n; i++)
            proce_size[i] = processSize[i].p_size;

        for (int i = 0; i < proce_size.length; i++)
            proce_size[i] = -1;

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                if (b_s[j] >= p_s[i]) {
                    proce_size[i] = j;
                    b_s[j] -= p_s[i];
                    break;
                }

            }
        }


        System.out.println("Fragmentation:");
        for (int i = 0; i < b_s.length; i++) {
            System.out.println(b_s[i]);
        }


        System.out.println("\nProcess Name\t\tProcess Size\t\tPartition no.");
        for (int i = 0; i < n; i++) {
            System.out.print(" " + processSize[i].p_name + "\t\t\t\t\t\t" + processSize[i].p_size + "\t\t\t\t");
            int partition = proce_size[i];
            if (proce_size[i] != -1)
                System.out.print("Partition" + partition);
            else
                System.out.print("Not Allocated");
            System.out.println();
        }
//        /******* Partition free space *******/
//        System.out.println("Partition free space:");
//        for (int i = 0; i < m; i++) {
//            if (b_s[i] != 0) {
//                System.out.println(blockSize[i].parti_name + " = " + b_s[i]);
//            }
//        }
    }
}