import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
    public class Main {
        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);

            // Read the number of partitions
            System.out.println("Enter number of partition:");
            int numPartitions = scanner.nextInt();
            scanner.nextLine();  // consume the newline character

            // Read the partition sizes
            List<Partition> partitions = new ArrayList<>();
            for (int i = 0; i < numPartitions; i++) {
                System.out.println("Enter number of partition:");
                String[] parts = scanner.nextLine().split(" ");
                int size = Integer.parseInt(parts[1]);
                partitions.add(new Partition(size, true));
            }

            // Read the number of processes
            System.out.println("Enter number of processes:");
            int numProcesses = scanner.nextInt();
            scanner.nextLine();  // consume the newline character

            // Read the process sizes
            List<Process> processes = new ArrayList<>();
            for (int i = 0; i < numProcesses; i++) {
                System.out.println("Process name and its size:");
                String[] parts = scanner.nextLine().split(" ");
                String name = parts[0];
                int size = Integer.parseInt(parts[1]);
                processes.add(new Process(name, size));
            }

            // Select the allocation policy
            System.out.println("Select the policy you want to apply:");
            System.out.println("1. First fit");
            System.out.println("2. Worst fit");
            System.out.println("3. Best fit");
            System.out.println("Select policy:");
            int policy = scanner.nextInt();

            // Create the memory allocator
            MemoryAllocator allocator = new MemoryAllocator(partitions);

            // Allocate the processes according to the selected policy
            for (Process p : processes) {
                switch (policy) {
                    case 1:
                        allocator.firstFit(p);
                        break;
                    case 2:
                        allocator.worstFit(p);
                        break;
                    case 3:
                        allocator.bestFit(p);
                        break;
                    default:
                        System.out.println("Invalid policy");
                }
            }





            // Print the final partition state
            for (int i = 0; i < numPartitions; i++) {
                Partition partition = partitions.get(i);
                System.out.print("Partition " + i + " (" + partition.getSize() + " KB) => ");
                if (partition.isFree()) {
                    System.out.println("External fragment");
                } else {
                    boolean found = false;
                    for (Process p : processes) {
                        if (!p.isAllocated()) {
                            continue;
                        }
                        if (p.getAllocatedPartition().equals(partition)) {
                            System.out.println(p.getName());
                            found = true;
                            break;
                        }
                    }
                    if (!found) {
                        System.out.println("External fragment");
                    }
                }
            }
        }
    }

