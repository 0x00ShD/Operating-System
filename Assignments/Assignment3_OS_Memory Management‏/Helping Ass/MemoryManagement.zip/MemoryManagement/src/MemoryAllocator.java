import java.util.List;

public class MemoryAllocator {
    // Class that implements the different memory allocation algorithms
    private List<Partition> partitions;

    public MemoryAllocator(List<Partition> partitions) {
        this.partitions = partitions;
    }

    public void firstFit(Process p) {
        // Allocate the first free partition that is large enough to fit the process
        for (Partition partition : partitions) {
            if (partition.isFree() && partition.getSize() >= p.getSize()) {
                partition.setFree(false);
                System.out.println("Allocated process " + p.getName() + " to partition with size " + partition.getSize());
                return;
            }
        }
        System.out.println("Could not allocate process " + p.getName() + " - no suitable partition found");
    }

    public void bestFit(Process p) {
        // Allocate the smallest free partition that is large enough to fit the process
        Partition bestPartition = null;
        for (Partition partition : partitions) {
            if (partition.isFree() && partition.getSize() >= p.getSize()) {
                if (bestPartition == null || partition.getSize() < bestPartition.getSize()) {
                    bestPartition = partition;
                }
            }
        }
        if (bestPartition != null) {
            bestPartition.setFree(false);
            System.out.println("Allocated process " + p.getName() + " to partition with size " + bestPartition.getSize());
        } else {
            System.out.println("Could not allocate process " + p.getName() + " - no suitable partition found");
        }
    }

    public void worstFit(Process p) {
        // Allocate the largest free partition that is large enough to fit the process
        Partition worstPartition = null;
        for (Partition partition : partitions) {
            if (partition.isFree() && partition.getSize() >= p.getSize()) {
                if (worstPartition == null || partition.getSize() > worstPartition.getSize()) {
                    worstPartition = partition;
                }
            }
        }
        if (worstPartition != null) {
            worstPartition.setFree(false);
            System.out.println("Allocated process " + p.getName() + " to partition with size " + worstPartition.getSize());
        } else {
            System.out.println("Could not allocate process " + p.getName() + " - no suitable partition found");
        }
    }

    public void compactMemory() {
        int i = 0;
        int j = partitions.size() - 1;
        while (i < j) {
            while (i < j && !partitions.get(i).isFree()) {
                i++;
            }
            while (i < j && partitions.get(j).isFree()) {
                j--;
            }
            if (i < j) {
                Partition temp = partitions.get(i);
                partitions.set(i, partitions.get(j));
                partitions.set(j, temp);
            }
        }
    }
}