public class Partition {
    // Represents a memory partition
    private int size;
    private boolean isFree;

    public Partition(int size, boolean isFree) {
        this.size = size;
        this.isFree = isFree;
    }

    public int getSize() {
        return size;
    }

    public boolean isFree() {
        return isFree;
    }

    public void setFree(boolean free) {
        isFree = free;
    }
}
