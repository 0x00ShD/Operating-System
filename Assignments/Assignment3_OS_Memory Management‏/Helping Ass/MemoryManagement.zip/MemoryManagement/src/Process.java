public class Process {
    // Represents a process that needs to be allocated memory
    private String name;
    private int size;
    private boolean isAllocated;
    private Partition allocatedPartition;

    public Process(String name, int size) {
        this.name = name;
        this.size = size;
        this.isAllocated = false;
        this.allocatedPartition = null;
    }

    public String getName() {
        return name;
    }

    public int getSize() {
        return size;
    }

    public boolean isAllocated() {
        return isAllocated;
    }

    public void setAllocated(boolean allocated) {
        isAllocated = allocated;
    }

    public Partition getAllocatedPartition() {
        return allocatedPartition;
    }

    public void setAllocatedPartition(Partition allocatedPartition) {
        this.allocatedPartition = allocatedPartition;
    }
}